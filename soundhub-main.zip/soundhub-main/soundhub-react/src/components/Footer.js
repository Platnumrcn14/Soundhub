//displays the footer.
import "./styling.css";


export default function Footer(){

    return(

            <div>
          
               <footer className="footer">
                 SoundHub &copy; 2023 Sai Kumar Cherku, Sneha Chitre, Tracy Hockenhull, Derek Norton from an idea by Gus Gamboa.
               </footer>
               
             </div>


    );
}