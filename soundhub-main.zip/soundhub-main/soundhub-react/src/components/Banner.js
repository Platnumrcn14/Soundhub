//displays the Banner 
import "./styling.css";

export default function Banner(){

    return(

            <div className = "banner">
                
               <header><h1> Welcome to SoundHub</h1></header>
               {/* <img src = "./images/SL.123119.26540.04.jpg" alt = "glowing-musical-pentagram-background-with-sound-notes" className = "bannerimg"/> */}

            </div>

    );
    
}